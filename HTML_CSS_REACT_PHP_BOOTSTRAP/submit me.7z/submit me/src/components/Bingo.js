// import the React library from 'react'
import React from 'react';
// import the Bingo.css
import './Bingo.css';

// Define class Bingo that extends React.Component
class Bingo extends React.Component{     
    // Define the constructor method, parameter list includes props
    constructor(props){
        // Call the super constructor method, pass parameter props as an argument
        super(props)
        // Initialize the state object
        this.state = {
            // Add property data: initialize to method call populateData()
            data:this.populateData(),
            // Add property card: initialize to method call populateCard()
            card:this.populateCard()
        };
    }
    
    // Define method populateData, empty parameter list
    populateData(){
        // Declare variable data initiliazed to and empty array using the literal implementation
        const numbers = [];

        
        // iterate to generate the Bingo numbers 1 - 75 and push on the array data
        // be sure to start the loop control value at 1 versus 0 to simulate Bingo numbers
        for(let i = 1; i <75; i++){
            numbers.push(i);
        }
        
        // return the array data
        return numbers;
    }
    
    // Define method populateCard, empty parameter list
    populateCard(){
        // Define a constant (i.e., numbers) initialized to state object property data
        const numbers = this.data;
        
        // Declare variable card initiliazed to and empty array using the literal implementation
        const card = [];
        
        // Iterate for the five rows 
        for(let i=0; i<5; i++)
        {            
            // Declare variable offset initialized to the row loop control variable multiplied by 15 is use as an offset for the array index
            const row = [];
            const rowOffset = i*15;
            
            // Iterate until each column has five unique values randomly selected
            for(let j=0; j<5; j++)
            {
                // Declare variable idx to use as the index of the numbers array
                let idx = rowOffset + (Math.floor((Math.random() * 15)));
                
                
                // Initialize idx to a random number based on the column letter
                // Use a similar implementation as Assignment 2 JavaScript
                // Ensure no duplicates by checking if the card array includes the value stored in the numbers array at index idx
                // If the value is not already in the card array  
                row.push(idx);
            }
            // push the value stored in the numbers array at index idx on to the card array
            card.push(row);
        }

        // return the card array
        return card;
    }
    
    // Declare method getNumber with one parameter (i.e., idx)

    getNumber(idx){
        // Declare constant bingoCard initialized to the state object propery card
        const bingoCard = this.populateCard();
        
        // Declare variable number initialized to array bingoCard at index idx
        const number = bingoCard[idx];

        // Return variable number
        return number;
    }
    
    // Declare method render()

    render(){
      // Return the element
      // Write the JSX
            // Create a div element with id bingo-container
            // Create a div element with id board
            // Create a div element with class row
            // Create a div element with class bingo
                // Create a span element with the inner JSX calling method getNumber() passing 0 as an argument
            // Create a div element with class bingo
                // Create a span element with the inner JSX calling method getNumber() passing 5 as an argument
            // Create a div element with class bingo
                    // Create a span element with the inner JSX calling method getNumber() passing 10 as an argument
            // Create a div element with class bingo
                // Create a span element with the inner JSX calling method getNumber() passing 15 as an argument
            // Create a div element with class bingo
                // Create a span element with the inner JSX calling method getNumber() passing 20 as an argument
            // Repeat above row four more times
                // Increment the argument values by +1
                // This is a similar implementation we used in the JavaScript assignment where we created the id (i.e., #cell##) incrementally then had to use the same value as the id attribute in the HTML
                // For the third row, ensure the third column is explictly set to the text 'FREE'
        return (
            <html>
                <body>
                    <div id="bingo-container">
                        <div id="board">
                            <div className="row">
                                <div className="bingo"><span>{this.getNumber(0)}</span></div>
                                <div className="bingo"><span>{this.getNumber(5)}</span></div>
                                <div className="bingo"><span>{this.getNumber(10)}</span></div>
                                <div className="bingo"><span>{this.getNumber(15)}</span></div>
                                <div className="bingo"><span>{this.getNumber(20)}</span></div>
                            </div>
                            <div className="row">
                                <div className="bingo"><span>{this.getNumber(1)}</span></div>
                                <div className="bingo"><span>{this.getNumber(6)}</span></div>
                                <div className="bingo"><span>{this.getNumber(11)}</span></div>
                                <div className="bingo"><span>{this.getNumber(16)}</span></div>
                                <div className="bingo"><span>{this.getNumber(21)}</span></div>
                            </div>
                            <div className="row">
                                <div className="bingo"><span>{this.getNumber(2)}</span></div>
                                <div className="bingo"><span>{this.getNumber(7)}</span></div>
                                <div className="bingo"><span>Free</span></div>
                                <div className="bingo"><span>{this.getNumber(17)}</span></div>
                                <div className="bingo"><span>{this.getNumber(22)}</span></div>
                            </div>
                            <div className="row">
                                <div className="bingo"><span>{this.getNumber(3)}</span></div>
                                <div className="bingo"><span>{this.getNumber(8)}</span></div>
                                <div className="bingo"><span>{this.getNumber(13)}</span></div>
                                <div className="bingo"><span>{this.getNumber(18)}</span></div>
                                <div className="bingo"><span>{this.getNumber(23)}</span></div>
                            </div>
                            <div className="row">
                                <div className="bingo"><span>{this.getNumber(4)}</span></div>
                                <div className="bingo"><span>{this.getNumber(9)}</span></div>
                                <div className="bingo"><span>{this.getNumber(14)}</span></div>
                                <div className="bingo"><span>{this.getNumber(19)}</span></div>
                                <div className="bingo"><span>{this.getNumber(24)}</span></div>
                            </div>
                        </div>
                    </div>
                </body>
            </html>
        );
   }
}

// Include the export default statement
export default Bingo;
